#!/bin/bash
# PUNTO 5 - MOSTRAR AYUDA
show_help() {
    cat <<EOF
Uso: $(basename "$0") [-h|--help] -s <origen> -d <destino>

Opciones:
Obligatorias:
  -s <origen>      Ruta del directorio o archivo a respaldar.
  -d <destino>     Punto de montaje donde se guardará el backup.
                    Debe estar bajo la partición montada en /backup_dir.

Opcionales:
  -h, --help       Muestra esta ayuda y sale.

Ejemplos:
  $(basename "$0") -s /var/log -d /backup_dir
  $(basename "$0") -s /etc -d /backup_dir
EOF
    exit 0
}

# PUNTO 4 - ARGUMENTOS
while [[ $# -gt 0 ]]; do
    case "$1" in
        -s) ORIGEN="$2"; shift 2 ;;
        -d) DESTINO="$2"; shift 2 ;;
        -h|--help) show_help ;;
        *) echo "Opción desconocida: $1. Ver ayuda con -h o --help" >&2; exit 0 ;;
    esac
done

# PUNTO 6 - VALIDACIONES
if [[ -z "$ORIGEN" || -z "$DESTINO" ]]; then
    echo "Error: deben especificarse origen y destino." >&2
    exit 1
fi

if [[ ! -e "$ORIGEN" ]]; then
    echo "Error: el origen '$ORIGEN' no existe." >&2
    exit 1
fi

if [[ ! -e "$DESTINO" ]]; then
    echo "Error: el destino '$DESTINO' no existe." >&2
    exit 1
fi

if [[ ! -r "$ORIGEN" ]]; then
    echo "Error: el sistema de archivos del origen no está disponible." >&2
    exit 1
fi

if ! mountpoint -q "$DESTINO"; then
    echo "Error: el sistema de archivos del destino no está montado." >&2
    exit 1
fi

# PUNTO 2 - NOMBRE DEL ARCHIVO TAR.GZ
BASE_NAME=$(basename "$ORIGEN")
FECHA=$(date '+%Y%m%d')
ARCHIVO="${BASE_NAME}_bkp_${FECHA}.tar.gz"
RUTA_COMPLETA="${DESTINO%/}/${ARCHIVO}"

tar -czpf "$RUTA_COMPLETA" -C "$(dirname "$ORIGEN")" "$(basename "$ORIGEN")"


if [[ $? -eq 0 ]]; then
    echo "Backup exitoso:"
    echo "  Origen : $ORIGEN"
    echo "  Destino: $RUTA_COMPLETA"
else
    echo "Error durante la creación del backup." >&2
    exit 1
fi
