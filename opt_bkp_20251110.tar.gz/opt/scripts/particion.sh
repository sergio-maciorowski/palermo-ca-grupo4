#!/bin/bash
cat /proc/partitions > /opt/particion
